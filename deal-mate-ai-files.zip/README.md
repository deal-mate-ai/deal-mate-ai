
# DealMate.ai

This is a simple demo front-end for DealMate.ai – a smart property listing platform.

## Live Preview

Once deployed (e.g., to Netlify or GitHub Pages), this page will display property listings with price and city info.

## How to Deploy on Netlify

1. Go to [https://app.netlify.com](https://app.netlify.com)
2. Click **New Site from Git**
3. Choose this GitHub repo
4. Set build settings:
   - **Build command:** *(leave blank)*
   - **Publish directory:** `./`
5. Click **Deploy site**

## Demo Content

- 3 Property listings (Ahmedabad, Surat, Rajkot)
- Fully mobile responsive
